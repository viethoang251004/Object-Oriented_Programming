public class SinhVienTaiChuc extends SinhVien {
    private String noiLienKetDaoTao;

    public SinhVienTaiChuc(String maHocVien, String hoTen, String ngaySinh, int namVaoHoc, double diemDauVao, String noiLienKetDaoTao) {
        super(maHocVien, hoTen, ngaySinh, namVaoHoc, diemDauVao);
        this.noiLienKetDaoTao = noiLienKetDaoTao;
    }

    public String getNoiLienKetDaoTao() {
        return noiLienKetDaoTao;
    }
}
