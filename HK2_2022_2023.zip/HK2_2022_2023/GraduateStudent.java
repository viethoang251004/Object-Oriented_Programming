import java.util.*;

// Lớp học viên cao học
public class GraduateStudent extends Student {
    private String university;
    private String graduationDate;
    private String degreeId;
    private String graduationType;

    public GraduateStudent(String studentId, String fullName, String dateOfBirth, int enrollmentYear,
            double entranceScore, String university, String graduationDate, String degreeId, String graduationType) {
        super(studentId, fullName, dateOfBirth, enrollmentYear, entranceScore);
        this.university = university;
        this.graduationDate = graduationDate;
        this.degreeId = degreeId;
        this.graduationType = graduationType;
    }

    public String getUniversity() {
        return university;
    }

    public String getGraduationDate() {
        return graduationDate;
    }

    public String getDegreeId() {
        return degreeId;
    }

    public String getGraduationType() {
        return graduationType;
    }
}
