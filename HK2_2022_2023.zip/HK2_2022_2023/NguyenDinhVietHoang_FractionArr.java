class NguyenDinhVietHoang_FractionArr implements NguyenDinhVietHoang_IFraction {
    // Data members
    private int[] members;

    // Constructors
    public NguyenDinhVietHoang_FractionArr() {
        this(1, 1);
    }

    public NguyenDinhVietHoang_FractionArr(int numer, int denom) {
        members = new int[2];
        setNumer(numer);
        setDenom(denom);
    }

    // Accessors
    public int getNumer() {
        return members[0];
    }

    public int getDenom() {
        return members[1];
    }

    // Mutators
    public void setNumer(int numer) {
        members[0] = numer;
    }

    public void setDenom(int denom) {
        members[1] = denom;
    }

    @Override
    public NguyenDinhVietHoang_IFraction add(NguyenDinhVietHoang_IFraction f) {
        int numer = this.getNumer() * f.getDenom() + f.getNumer() * this.getDenom();
        int denom = this.getDenom() * f.getDenom();
        return new NguyenDinhVietHoang_FractionArr(numer, denom).simplify();
    }

    @Override
    public NguyenDinhVietHoang_IFraction minus(NguyenDinhVietHoang_IFraction f) {
        int numer = this.getNumer() * f.getDenom() - f.getNumer() * this.getDenom();
        int denom = this.getDenom() * f.getDenom();
        return new NguyenDinhVietHoang_FractionArr(numer, denom).simplify();
    }

    @Override
    public NguyenDinhVietHoang_IFraction times(NguyenDinhVietHoang_IFraction f) {
        int numer = this.getNumer() * f.getNumer();
        int denom = this.getDenom() * f.getDenom();
        return new NguyenDinhVietHoang_FractionArr(numer, denom).simplify();
    }

    @Override
    public NguyenDinhVietHoang_IFraction simplify() {
        int gcd = getGcd(this.getNumer(), this.getDenom());
        int numer = this.getNumer() / gcd;
        int denom = this.getDenom() / gcd;
        return new NguyenDinhVietHoang_FractionArr(numer, denom);
    }

    private int getGcd(int a, int b) {
        if (b == 0) {
            return a;
        }
        return getGcd(b, a % b);
    }
}