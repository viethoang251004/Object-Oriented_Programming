import java.util.*;

// Sử dụng các lớp và phương thức trong hệ thống quản lý học viên
public class Main {
    public static void main(String[] args) {
        StudentManagementSystem managementSystem = new StudentManagementSystem();

        // Thêm các khoa
        managementSystem.addDepartment("Khoa Cong nghe thong tin");
        managementSystem.addDepartment("Khoa Kinh te");
        managementSystem.addDepartment("Khoa Ngoai ngu");

        // Tạo sinh viên
        Student student1 = new RegularStudent("SV001", "Nguyen Van A", "01/01/2000", 2021, 8.5);
        Student student2 = new PartTimeStudent("SV002", "Tran Thi B", "02/02/2001", 2021, 7.8, "Ha Noi");
        Student student3 = new GraduateStudent("HV001", "Pham Van C", "03/03/1999", 2021, 9.2, "Dai hoc ABC", "01/06/2023", "BC123", "Gioi");

        // Thêm sinh viên vào khoa
        managementSystem.addStudentToDepartment("Khoa Cong nghe thong tin", student1);
        managementSystem.addStudentToDepartment("Khoa Kinh te", student2);
        managementSystem.addStudentToDepartment("Khoa Ngoai ngu", student3);

        // Thêm môn học cho sinh viên
        student1.getCourses().add("Lap trinh Java");
        student2.getCourses().add("Quan tri kinh doanh");
        student2.getCourses().add("Tieng Anh giao tiep");
        student3.getCourses().add("Mang may tinh");

        // Thêm kết quả học tập cho sinh viên
        student1.addTranscriptResult("Hoc ky 1", 8.0);
        student1.addTranscriptResult("Hoc ky 2", 8.5);
        student2.addTranscriptResult("Hoc ky 1", 7.5);
        student3.addTranscriptResult("Hoc ky 1", 9.5);
        student3.addTranscriptResult("Hoc ky 2", 9.0);

        // Hiển thị sinh viên có điểm đầu vào cao nhất trong mỗi khoa
        managementSystem.findStudentsWithHighestEntranceScore();

        // Hiển thị danh sách học viên trong khoa
        managementSystem.displayStudentsInDepartment("Khoa Cong nghe thong tin");

        // Hiển thị chi tiết thông tin sinh viên
        managementSystem.displayStudentDetails("SV001");
    }
}
