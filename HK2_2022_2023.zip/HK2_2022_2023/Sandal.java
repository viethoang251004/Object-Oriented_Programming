import java.util.*;
import java.io.*;

class Sandal extends Product {
    private int strapCount;
    private String soleType;
    private int unitPrice;

    public Sandal() {
    }

    public Sandal(String productCode, String productName, String material, int size, String color, int productionYear,
            int strapCount, String soleType, int unitPrice) {
        super(productCode, productName, material, size, color, productionYear);
        this.strapCount = strapCount;
        this.soleType = soleType;
        this.unitPrice = unitPrice;
    }

    public int getStrapCount() {
        return strapCount;
    }

    public void setStrapCount(int strapCount) {
        this.strapCount = strapCount;
    }

    public String getSoleType() {
        return soleType;
    }

    public void setSoleType(String soleType) {
        this.soleType = soleType;
    }

    public int getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(int unitPrice) {
        this.unitPrice = unitPrice;
    }

    @Override
    public int calculateCost() {
        return unitPrice * 35000 + strapCount * 5000;
    }
}
