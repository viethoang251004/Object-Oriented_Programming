import java.util.*;
import java.io.*;
import java.time.Year;

public class TransactionProcessing {
    private ArrayList<Payment> paymentObjects;
    private IDCardManagement idcm;
    
    //Construtor
    public TransactionProcessing(String idCardPath, String paymentPath) {
        idcm = new IDCardManagement(idCardPath);
        readPaymentObject(paymentPath);
    }

    public ArrayList<Payment> getPaymentObject() {
        return this.paymentObjects;
    }

    // Requirement 3
    public boolean readPaymentObject(String path) {
        boolean isRead = true;
        try{
            paymentObjects = new ArrayList<Payment>();
            BufferedReader br = new BufferedReader(new FileReader(path));
            String line = null;

            while((line = br.readLine()) != null){
                String [] values = line.split(",");
                if(line.contains(",")){
                    //BankAccount
                    BankAccount ba = new BankAccount(Integer.parseInt(values[0]),Double.parseDouble(values[1]));
                    paymentObjects.add(ba);
                }
                else{
                    if(values[0].length() == 6){
                        //Convenient Card
                        int idNumber = Integer.parseInt(values[0]);
                        for(IDCard idc : idcm.getIDCards()){
                            if(idNumber == idc.getSoDinhDanh()){
                                ConvenientCard cc = new ConvenientCard(idc);
                                paymentObjects.add(cc);
                            }
                        }
                        
                    }
                    else if(values[0].length() == 7){
                        EWallet ew = new EWallet(Integer.parseInt(values[0]));
                        paymentObjects.add(ew);
                        //SoDienThoai
                    }
                } 
            }
            br.close();
        }catch(IOException e){
            e.printStackTrace();
            isRead = false;
        }finally{
            return isRead;
        }
        //code here
    }

    // Requirement 4
    public ArrayList<ConvenientCard> getAdultConvenientCards() {
        ArrayList<ConvenientCard> adultConvenient = new ArrayList<ConvenientCard>();
        for(Payment p : paymentObjects){
            if(p instanceof ConvenientCard){
                ConvenientCard adultCards = (ConvenientCard) p;
                try{
                    if(adultCards.getType().equals("Adult") == true){
                        adultConvenient.add(adultCards);
                    }
                }catch(CannotCreateCard cr){
                    cr.printStackTrace();
                }
            }
        }
        return adultConvenient;
        //code here
    }
    // Requirement 5
    public ArrayList<IDCard> getCustomersHaveBoth() {
        ArrayList<IDCard> haveBoth = new ArrayList<IDCard>();
        for(IDCard idc : idcm.getIDCards() ){
            int count = 0;
            for(Payment p : paymentObjects)
                if(p instanceof BankAccount){
                    BankAccount ba = (BankAccount) p;
                    if(ba.getSoTaiKhoan() == idc.getSoDinhDanh()){
                        count++;
                    }
                }
                else if(p instanceof EWallet){
                    EWallet ew = (EWallet) p;
                    if(ew.getSoDienThoai() == idc.getPhone()){
                        count++;
                    }
                }
                else if(p instanceof ConvenientCard){
                    ConvenientCard cc = (ConvenientCard) p;
                    if(cc.getID().getSoDinhDanh() == idc.getSoDinhDanh()){
                        count++;
                    }
                }
            if(count == 3){
                haveBoth.add(idc);
            }
        }
        return haveBoth;
        //code here
        //return null;
    }

    // Requirement 6
    public void processTopUp(String path) {
        try{
            BufferedReader br = new BufferedReader(new FileReader(path));
            String line = null;
            while((line = br.readLine()) != null){
                String [] values = line.split(",");
                if(values[0].equals("BA") == true){
                    for(Payment p : paymentObjects){
                        if(p instanceof BankAccount){
                            BankAccount taiKhoanNap = (BankAccount) p;
                            if(taiKhoanNap.getSoTaiKhoan() == Integer.parseInt(values[1])){
                                taiKhoanNap.topUp(Double.parseDouble(values[2]));
                            }
                        }
                    }
                }
                else if(values[0].equals("EW") == true){
                    for(Payment p : paymentObjects){
                        if(p instanceof EWallet){
                            EWallet viNap = (EWallet) p;
                            if(viNap.getSoDienThoai() == Integer.parseInt(values[1])){
                                viNap.topUp(Double.parseDouble(values[2]));
                            }
                        }
                    }
                }
                else{
                    for(Payment p : paymentObjects){
                        if(p instanceof ConvenientCard){
                            ConvenientCard theNap = (ConvenientCard) p;
                            if(theNap.getID().getSoDinhDanh() == Integer.parseInt(values[1])){
                                theNap.topUp(Double.parseDouble(values[2]));
                            }
                        }
                    }
                }
            }
            br.close();
        }catch(IOException e){
            e.printStackTrace();
        }
        //code here
    }
    // Requirement 7
    public ArrayList<Bill> getUnsuccessfulTransactions(String path) {
        ArrayList<Bill> unSuccess = new ArrayList<Bill>();
        try{
            BufferedReader br = new BufferedReader(new FileReader(path));
            String line = null;
            while((line = br.readLine()) != null){
                String [] values = line.split(",");
                if(values[3].equals("BA") == true){
                    for(Payment p : paymentObjects){
                        if(p instanceof BankAccount){
                            BankAccount BA = (BankAccount) p;
                            if(BA.getSoTaiKhoan() == Integer.parseInt(values[4])){
                                if(BA.pay(Double.parseDouble(values[1])) == false){
                                    Bill failBA = new Bill(Integer.parseInt(values[0]),Double.parseDouble(values[1]),values[2]);
                                    unSuccess.add(failBA);
                                }
                            }
                        }
                    }
                }
                else if(values[3].equals("EW") == true){
                    for(Payment p : paymentObjects){
                        if(p instanceof EWallet){
                            EWallet EW = (EWallet) p;
                            if(EW.getSoDienThoai() == Integer.parseInt(values[4])){
                                if(EW.pay(Double.parseDouble(values[1])) == false){
                                    Bill failEW = new Bill(Integer.parseInt(values[0]),Double.parseDouble(values[1]),values[2]);
                                    unSuccess.add(failEW);
                                }
                            }
                        }
                    }
                }
                else{
                    for(Payment p : paymentObjects){
                        if(p instanceof ConvenientCard){
                            ConvenientCard CC = (ConvenientCard) p;
                            if(CC.getID().getSoDinhDanh() == Integer.parseInt(values[4])){
                                if(CC.pay(Double.parseDouble(values[1])) == false){
                                    Bill failCC = new Bill(Integer.parseInt(values[0]),Double.parseDouble(values[1]),values[2]);
                                    unSuccess.add(failCC);
                                }
                            }
                        }
                    }
                }
            }
            br.close();
            return unSuccess;
        }catch(IOException e){
            e.printStackTrace();
            return null;
        }
        //code here
    }

    // Requirement 8
    public ArrayList<BankAccount> getLargestPaymentByBA(String path) {
        /*ArrayList<BankAccount> largestPaymentBA = new ArrayList<BankAccount>();
        ArrayList<BankAccount> successBA = new ArrayList<BankAccount>();

        try{
            BufferedReader br = new BufferedReader(new FileReader(path));
            String line = null;
            while((line = br.readLine()) != null){
                String [] values = line.split(",");
                double tienPhaiTra = 0;
                if(values[3].equals("BA") == true){
                    /*int numberID = Integer.parseInt(values[4]);
                    tienPhaiTra += Double.parseDouble(values[1]);
                    while((line = br.readLine()) != null){
                        if(numberID == Integer.parseInt(values[4])){
                            tienPhaiTra += Double.parseDouble(values[1]);
                        }
                    }
                    for(Payment p : paymentObjects){
                        if(p instanceof BankAccount){
                            BankAccount bac = (BankAccount) p;
                            if(bac.getSoTaiKhoan() == Integer.parseInt(values[4])){
                                if(bac.pay(Double.parseDouble(values[1])) == true){
                                    successBA.add(bac);
                                }
                            }
                        }
                    }
                }
            }
            //for(BankAccount baic : successBA)
            br.close();
            return successBA;
        }catch(IOException e){
            e.printStackTrace();
            return null;
        }*/
        return null;
        //code here
    }
    //Requirement 9
    public void processTransactionWithDiscount(String path) {
        Year thisYear = Year.now();
		int recentYear = thisYear.getValue();
        try{
            BufferedReader br = new BufferedReader(new FileReader(path));
            String line = null;
            while((line = br.readLine()) != null){
                String values[] = line.split(",");
                if(values[3].equals("BA")){
                    for(Payment p : paymentObjects){
                        if(p instanceof BankAccount){
                            BankAccount taiKhoanNganHang = (BankAccount) p;
                            if(taiKhoanNganHang.getSoTaiKhoan() == Integer.parseInt(values[4])){
                                if(taiKhoanNganHang.soDuTaiKhoan >= Double.parseDouble(values[1])){
                                    taiKhoanNganHang.pay(Double.parseDouble(values[1]));
                                }
                            }
                        }
                    }
                }    
                else if(values[3].equals("EW") && values[2].equals("Clothing")){
                    for(IDCard idc : idcm.getIDCards() ){
                        for(Payment p : paymentObjects){
                            if(p instanceof EWallet){
                                if(Double.parseDouble(values[1]) > 500){
                                    double soTienPhaiTra = Double.parseDouble(values[1])*(1 - 0.15);
                                    EWallet viDienTu = (EWallet) p;
                                    if(viDienTu.getSoDienThoai() == idc.getPhone()){
                                        if(viDienTu.getSoDienThoai() == Integer.parseInt(values[4])){
                                            String [] date = idc.getNgayThangNamSinh().split("/");
                                            int namSinh  = Integer.parseInt(date[2]);
                                            if(idc.getGioiTinh().equals("Male") && recentYear - namSinh <= 20){
                                                if(viDienTu.soDuTaiKhoan >= soTienPhaiTra){
                                                    viDienTu.pay(soTienPhaiTra);
                                                }
                                            }
                                            else if(idc.getGioiTinh().equals("Female") && recentYear - namSinh <= 18){
                                                if(viDienTu.soDuTaiKhoan >= soTienPhaiTra){
                                                    viDienTu.pay(soTienPhaiTra);
                                                }
                                            }
                                        }
                                    }
                                }
                                else if(Double.parseDouble(values[1]) <= 500){
                                    EWallet viDien = (EWallet) p;
                                    if(viDien.getSoDienThoai() == Integer.parseInt(values[4])){
                                        if(viDien.soDuTaiKhoan >= Double.parseDouble(values[1])){
                                            viDien.pay(Double.parseDouble(values[1]));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else if(values[3].equals("CC")){
                    for(Payment p : paymentObjects){
                        if(p instanceof ConvenientCard){
                            ConvenientCard theTienLoi = (ConvenientCard) p;
                            if(theTienLoi.getID().getSoDinhDanh() == Integer.parseInt(values[4])){
                                if(theTienLoi.soDuTaiKhoan >= Double.parseDouble(values[1])){
                                    theTienLoi.pay(Double.parseDouble(values[1]));
                                }
                            }
                        }
                    }
                }
                else if(values[3].equals("EW")){
                    for(Payment p : paymentObjects){
                        if(p instanceof EWallet){
                            EWallet viDienTu2 = (EWallet) p;
                            if(viDienTu2.getSoDienThoai() == Integer.parseInt(values[4])){
                                if(viDienTu2.soDuTaiKhoan >= Double.parseDouble(values[1])){
                                    viDienTu2.pay(Double.parseDouble(values[1]));
                                }
                            }
                        }
                    }
                }
            }
            br.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
        //code here
    }
}
