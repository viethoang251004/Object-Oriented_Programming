public class KetQuaHocTap {
    private String hocKy;
    private double diemTrungBinh;

    public KetQuaHocTap(String hocKy, double diemTrungBinh) {
        this.hocKy = hocKy;
        this.diemTrungBinh = diemTrungBinh;
    }

    public String getHocKy() {
        return hocKy;
    }

    public double getDiemTrungBinh() {
        return diemTrungBinh;
    }
}
