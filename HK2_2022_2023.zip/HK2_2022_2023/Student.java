import java.util.*;

// Lớp học viên
public class Student {
    private String studentId;
    private String fullName;
    private String dateOfBirth;
    private int enrollmentYear;
    private double entranceScore;
    private List<String> courses; // Danh sách môn học
    private List<Transcript> transcripts; // Danh sách kết quả học tập

    public Student(String studentId, String fullName, String dateOfBirth, int enrollmentYear, double entranceScore) {
        this.studentId = studentId;
        this.fullName = fullName;
        this.dateOfBirth = dateOfBirth;
        this.enrollmentYear = enrollmentYear;
        this.entranceScore = entranceScore;
        this.courses = new ArrayList<>();
        this.transcripts = new ArrayList<>();
    }

    // Constructor sao chép
    public Student(Student other) {
        this.studentId = other.studentId;
        this.fullName = other.fullName;
        this.dateOfBirth = other.dateOfBirth;
        this.enrollmentYear = other.enrollmentYear;
        this.entranceScore = other.entranceScore;
        this.courses = new ArrayList<>(other.courses);
        this.transcripts = new ArrayList<>(other.transcripts);
    }

    // Phương thức xác định loại học viên
    public String getType() {
        if (this instanceof RegularStudent) {
            return "Sinh vien chinh quy";
        } else if (this instanceof PartTimeStudent) {
            return "Sinh vien tai chuc";
        } else if (this instanceof GraduateStudent) {
            return "Hoc vien cao hoc";
        } else {
            return "Khong xac đinh";
        }
    }

    // Phương thức lấy điểm trung bình các môn học của sinh viên dựa vào học kỳ
    public void addTranscriptResult(String semester, double averageScore) {
        for (Transcript transcript : transcripts) {
            if (transcript.getSemester().equals(semester)) {
                transcript.setAverageScore(averageScore);
                return;
            }
        }
        transcripts.add(new Transcript(semester, averageScore));
    }

    public String getStudentId() {
        return studentId;
    }

    public String getFullName() {
        return fullName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public int getEnrollmentYear() {
        return enrollmentYear;
    }

    public double getEntranceScore() {
        return entranceScore;
    }

    public List<String> getCourses() {
        return courses;
    }

    public List<Transcript> getTranscripts() {
        return transcripts;
    }
}
