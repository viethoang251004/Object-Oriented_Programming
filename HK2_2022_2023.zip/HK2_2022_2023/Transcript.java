import java.util.*;

// Lớp kết quả học tập
public class Transcript {
    private String semester;
    private double averageScore;

    public Transcript(String semester, double averageScore) {
        this.semester = semester;
        this.averageScore = averageScore;
    }

    public String getSemester() {
        return semester;
    }

    public double getAverageScore() {
        return averageScore;
    }

    public void setAverageScore(double averageScore) {
        this.averageScore = averageScore;
    }
}
