import java.util.*;

// Lớp sinh viên chính quy
public class RegularStudent extends Student {
    public RegularStudent(String studentId, String fullName, String dateOfBirth, int enrollmentYear,
            double entranceScore) {
        super(studentId, fullName, dateOfBirth, enrollmentYear, entranceScore);
    }
}
