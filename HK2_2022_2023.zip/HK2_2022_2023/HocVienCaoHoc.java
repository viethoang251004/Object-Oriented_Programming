public class HocVienCaoHoc extends SinhVien {
    private String truongDaiHocTotNghiep;
    private String ngayTotNghiep;
    private String maVanBang;
    private String totNghiepLoai;

    public HocVienCaoHoc(String maHocVien, String hoTen, String ngaySinh, int namVaoHoc, double diemDauVao, String truongDaiHocTotNghiep, String ngayTotNghiep, String maVanBang, String totNghiepLoai) {
        super(maHocVien, hoTen, ngaySinh, namVaoHoc, diemDauVao);
        this.truongDaiHocTotNghiep = truongDaiHocTotNghiep;
        this.ngayTotNghiep = ngayTotNghiep;
        this.maVanBang = maVanBang;
        this.totNghiepLoai = totNghiepLoai;
    }

    public String getTruongDaiHocTotNghiep() {
        return truongDaiHocTotNghiep;
    }

    public String getNgayTotNghiep() {
        return ngayTotNghiep;
    }

    public String getMaVanBang() {
        return maVanBang;
    }

    public String getTotNghiepLoai() {
        return totNghiepLoai;
    }
}
