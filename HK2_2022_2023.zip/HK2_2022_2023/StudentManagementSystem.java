import java.util.*;

// Lớp quản lý dữ liệu học viên
public class StudentManagementSystem {
    private Map<String, Department> departments; // Danh sách các khoa

    public StudentManagementSystem() {
        this.departments = new HashMap<>();
    }

    // Phương thức thêm khoa
    public void addDepartment(String departmentName) {
        Department department = new Department(departmentName);
        departments.put(departmentName, department);
    }

    // Phương thức thêm sinh viên vào khoa
    public void addStudentToDepartment(String departmentName, Student student) {
        Department department = departments.get(departmentName);
        if (department != null) {
            department.addStudent(student);
        } else {
            System.out.println("Khong tim thay khoa.");
        }
    }

    // Phương thức tìm sinh viên có điểm đầu vào cao nhất trong mỗi khoa
    public void findStudentsWithHighestEntranceScore() {
        for (Department department : departments.values()) {
            double maxEntranceScore = 0;
            Student studentWithMaxEntranceScore = null;
            for (Student student : department.getStudents()) {
                if (student.getEntranceScore() > maxEntranceScore) {
                    maxEntranceScore = student.getEntranceScore();
                    studentWithMaxEntranceScore = student;
                }
            }
            if (studentWithMaxEntranceScore != null) {
                System.out.println("Khoa: " + department.getDepartmentName());
                System.out.println("Sinh vien có diem dau vao cao nhat: " + studentWithMaxEntranceScore.getFullName());
                System.out.println("Diem dau vao: " + studentWithMaxEntranceScore.getEntranceScore());
                System.out.println("--------------------------------");
            }
        }
    }

    // Phương thức hiển thị danh sách học viên trong khoa
    public void displayStudentsInDepartment(String departmentName) {
        Department department = departments.get(departmentName);
        if (department != null) {
            List<Student> students = department.getStudents();
            System.out.println("Danh sach hoc vien trong khoa " + departmentName + ":");
            for (Student student : students) {
                System.out.println(student.getStudentId() + " - " + student.getFullName() + " - " + student.getEnrollmentYear());
            }
        } else {
            System.out.println("Khong tim thay khoa.");
        }
    }

    // Phương thức hiển thị chi tiết thông tin học viên
    public void displayStudentDetails(String studentId) {
        Student student = findStudentById(studentId);
        if (student != null) {
            System.out.println("Thong tin hoc vien:");
            System.out.println("Ma hoc vien: " + student.getStudentId());
            System.out.println("Ho va ten: " + student.getFullName());
            System.out.println("Ngay sinh: " + student.getDateOfBirth());
            System.out.println("Nam vao hoc: " + student.getEnrollmentYear());
            System.out.println("Loai hoc vien: " + student.getType());
            if (student instanceof PartTimeStudent) {
                System.out.println("Noi lien ket đao tao: " + ((PartTimeStudent) student).getTrainingLocation());
            } else if (student instanceof GraduateStudent) {
                GraduateStudent graduateStudent = (GraduateStudent) student;
                System.out.println("Truong dai hoc da tot nghiep: " + graduateStudent.getUniversity());
                System.out.println("Ngay tot nghiep: " + graduateStudent.getGraduationDate());
                System.out.println("Ma van bang: " + graduateStudent.getDegreeId());
                System.out.println("Tot nghiep loai: " + graduateStudent.getGraduationType());
            }
            System.out.println("Danh sach mon hoc:");
            List<String> courses = student.getCourses();
            for (String course : courses) {
                System.out.println(course);
            }
            System.out.println("Danh sach ket qua hoc tap:");
            List<Transcript> transcripts = student.getTranscripts();
            for (Transcript transcript : transcripts) {
                System.out.println("Hoc ky: " + transcript.getSemester());
                System.out.println("Diem trung binh: " + transcript.getAverageScore());
            }
        } else {
            System.out.println("Khong tim thay hoc vien.");
        }
    }

    // Phương thức tìm học viên theo mã học viên
    private Student findStudentById(String studentId) {
        for (Department department : departments.values()) {
            for (Student student : department.getStudents()) {
                if (student.getStudentId().equals(studentId)) {
                    return student;
                }
            }
        }
        return null;
    }
}