import java.util.ArrayList;

public class Test {
    public static void main(String[] NguyenDinhVietHoang) {
        ArrayList<KhachHang> danhSachKhachHang = new ArrayList<>();
        danhSachKhachHang.add(new KhachHangMoi("522H0120", "Hoang", "nam", "004 lo K", 23));
        danhSachKhachHang.add(new KhachHangThanThiet("522H0129", "Nguyet", "nu", "005 lo H", 62, 100));
        danhSachKhachHang.add(new KhachHangVIP("522H0123", "Minh", "nam", "009 lo I", 34));
        for (KhachHang khachHang : danhSachKhachHang) {
            System.out.println(khachHang);
        }

        // KhachHangMoi khachHangMoi = new KhachHangMoi("522H0120", "Hoang", "nam", "004
        // lo K", 23);
        // System.out.println(khachHangMoi.toString());

        // KhachHangThanThiet khachHangThanThiet = new KhachHangThanThiet("522H0129",
        // "Nguyet", "nu", "005 lo H", 62, 100);
        // System.out.println(khachHangThanThiet.toString());

        // KhachHangVIP khachHangVIP = new KhachHangVIP("522H0123", "Minh", "nam", "009
        // lo I", 34);
        // System.out.println(khachHangVIP.toString());
    }
}
