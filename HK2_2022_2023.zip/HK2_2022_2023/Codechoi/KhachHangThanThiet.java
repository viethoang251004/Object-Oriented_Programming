public class KhachHangThanThiet extends KhachHang {
    private int soLuongDaMuaTinhDenThoiDiemHienTai;

    public KhachHangThanThiet(String maKH, String tenKH, String gioiTinh, String diaChi, int soLuong, int soLuongDaMuaTinhDenThoiDiemHienTai) {
        super(maKH, tenKH, gioiTinh, diaChi, soLuong);
        this.soLuongDaMuaTinhDenThoiDiemHienTai = soLuongDaMuaTinhDenThoiDiemHienTai;
    }

    public double tinhTongTien() {
        return this.soLuongDaMuaTinhDenThoiDiemHienTai * this.getGiaBanTrenHoaDon();
    }

    public double tinhThanhTien() {
        return (this.getSoLuong() * this.getGiaBanTrenHoaDon() - this.getSoLuong() / 30 * this.getGiaBanTrenHoaDon()) - (this.getSoLuong() * this.getGiaBanTrenHoaDon() - this.getSoLuong() / 30 * this.getGiaBanTrenHoaDon()) * 0.05;
    }

    public String toString() {
        return super.toString() + ", thanh tien cua hoa don: " + this.tinhThanhTien() + ", tong tien ma khach hang da mua cua cong ty: " + this.tinhTongTien();
    }

    public int getSoLuongDaMuaTinhDenThoiDiemHienTai() {
        return this.soLuongDaMuaTinhDenThoiDiemHienTai;
    }

    public void setSoLuongDaMuaTinhDenThoiDiemHienTai(int soLuongDaMuaTinhDenThoiDiemHienTai) {
        this.soLuongDaMuaTinhDenThoiDiemHienTai = soLuongDaMuaTinhDenThoiDiemHienTai;
    }
}