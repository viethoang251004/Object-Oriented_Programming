public class HoaDonGiaoHang extends HoaDon {
    private String diaChi;
    private double khoangCach;
    private double thoiGianGiao;

    public HoaDonGiaoHang() {
        super();
        this.diaChi = "Q.Tan Phu";
        this.khoangCach = 20;
        this.thoiGianGiao = 24;
    }

    public double tinhThanhTien() {
        if (this.thoiGianGiao < 24) {
            if (this.khoangCach < 10) {
                return super.tinhThanhTien() + 20 * this.khoangCach * super.soLuong;
            } else {
                return super.tinhThanhTien() + 18 * this.khoangCach * super.soLuong;

            }
        } else {
            return super.tinhThanhTien() + 150000;
        }
    }

    public String xuatThongTin() {
        if (this.thoiGianGiao < 24) {
            if (this.khoangCach < 10) {
                return super.xuatThongTin() + ", phi giao hang: " + 20 * this.khoangCach * super.soLuong;
            } else {
                return super.xuatThongTin() + ", phi giao hang: " + 18 * this.khoangCach * super.soLuong;
            }
        } else {
            return super.xuatThongTin() + ", phi giao hang: " + 150000;
        }
    }
}