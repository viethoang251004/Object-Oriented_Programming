public class KhachHangVIP extends KhachHang {
    public KhachHangVIP(String maKH, String tenKH, String gioiTinh, String diaChi, int soLuong) {
        super(maKH, tenKH, gioiTinh, diaChi, soLuong);
    }

    public double tinhThanhTien() {
        return this.getSoLuong() * this.getGiaBanTrenHoaDon() - this.getSoLuong() * this.getGiaBanTrenHoaDon() * 0.1;
    }

    public String toString() {
        return super.toString() + ", thanh tien cua hoa don: " + (this.tinhThanhTien() - this.tinhThanhTien() * 0.07);
    }
}
