public class KhachHang {
    private String maKH;
    private String tenKH;
    private String gioiTinh;
    private String diaChi;
    private int soLuong;
    private final double giaBanTrenHoaDon = 50600.5;

    public KhachHang(String maKH, String tenKH, String gioiTinh, String diaChi, int soLuuong) {
        this.maKH = maKH;
        this.tenKH = tenKH;
        this.gioiTinh = gioiTinh;
        this.diaChi = diaChi;
        this.soLuong = soLuuong;
    }

    public String getMaKH() {
        return this.maKH;
    }

    public void setMaKH(String maKH) {
        this.maKH = maKH;
    }

    public String getTenKH() {
        return this.tenKH;
    }

    public void setTenKH(String tenKH) {
        this.tenKH = tenKH;
    }

    public String getGioiTinh() {
        return this.gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getDiaChi() {
        return this.diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public int getSoLuong() {
        return this.soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public double getGiaBanTrenHoaDon() {
        return this.giaBanTrenHoaDon;
    }

    public String toString() {
        return "Ma khach hang: " + this.maKH + ", ten khach hang: " + this.tenKH + ", gioi tinh: " + this.gioiTinh
                + ", dia chi: " + this.diaChi + ", so luong: " + this.soLuong + ", gia ban tren hoa don: " + this.giaBanTrenHoaDon;
    }
}
