public class KhachHangMoi extends KhachHang {
    public KhachHangMoi(String maKH, String tenKH, String gioiTinh, String diaChi, int soLuong) {
        super(maKH, tenKH, gioiTinh, diaChi, soLuong);
    }

    public double tinhThanhTien() {
        return this.getSoLuong() * this.getGiaBanTrenHoaDon();
    }

    public String toString() {
        return super.toString() + ", thanh tien cua hoa don: " + this.tinhThanhTien();
    }
}
