import java.util.*;

// Lớp môn học
public class Course {
    private String courseId;
    private String courseName;
    private double averageScore;

    public Course(String courseId, String courseName, double averageScore) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.averageScore = averageScore;
    }

    public String getCourseId() {
        return courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public double getAverageScore() {
        return averageScore;
    }

    public void setAverageScore(double averageScore) {
        this.averageScore = averageScore;
    }
}
