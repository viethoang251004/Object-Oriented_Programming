import java.util.*;
import java.io.*;

public abstract class Product {
    protected String productCode;
    protected String productName;
    protected String material;
    protected int size;
    protected String color;
    protected int productionYear;

    public Product() {
    }

    public Product(String productCode, String productName, String material, int size, String color,
            int productionYear) {
        this.productCode = productCode;
        this.productName = productName;
        this.material = material;
        this.size = size;
        this.color = color;
        this.productionYear = productionYear;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getProductionYear() {
        return productionYear;
    }

    public void setProductionYear(int productionYear) {
        this.productionYear = productionYear;
    }

    public abstract int calculateCost();

    public void inputProductInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhập mã sản phẩm: ");
        productCode = scanner.nextLine();
        System.out.print("Nhập tên sản phẩm: ");
        productName = scanner.nextLine();
        System.out.print("Nhập chất liệu: ");
        material = scanner.nextLine();
        System.out.print("Nhập kích thước: ");
        size = scanner.nextInt();
        scanner.nextLine(); // Đọc bỏ ký tự newline sau khi đọc số nguyên
        System.out.print("Nhập màu sắc: ");
        color = scanner.nextLine();
    }

    public void displayProductInfo() {
        System.out.println("Ma san pham: " + productCode);
        System.out.println("Ten san pham: " + productName);
        System.out.println("Chat lieu: " + material);
        System.out.println("Kich thuoc: " + size);
        System.out.println("Mau sac: " + color);
        System.out.println("--------------------------");
    }
}
