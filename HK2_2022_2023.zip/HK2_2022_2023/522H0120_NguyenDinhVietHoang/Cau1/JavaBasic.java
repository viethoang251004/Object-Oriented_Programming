import java.util.*;

public class JavaBasic {

    public static int sumNegativeElements(int[] a) {
        int sum = 0;
        for (int i = 0; i < a.length; i++) {
            if (a[i] < 0) {
                sum += a[i];
            }
        }
        return sum;
    }

    public static String uppercaseFirstVowels(String str) {
        String[] words = str.split(" ");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            String word = words[i];
            char first = Character.toUpperCase(word.charAt(0));
            String rest = word.substring(1);
            if ("AEIOUaeiou".indexOf(first) >= 0) {
                sb.append(first).append(rest);
            } else {
                sb.append(word);
            }
            if (i < words.length - 1) {
                sb.append(" ");
            }
        }
        return sb.toString();
    }

    public static int findMinNegativeElement(int[] a) {
        int minIndex = -1;
        for (int i = 0; i < a.length; i++) {
            if (a[i] < 0 && (minIndex == -1 || a[i] < a[minIndex])) {
                minIndex = i;
            }
        }
        return minIndex;
    }

    public static String getName(String str) {
        return str.substring(8);
    }

    public static int findFirstMod3Element(int[] a) {
        for (int i = 0; i < a.length; i++) {
            if (a[i] % 3 == 0) {
                return i;
            }
        }
        return -1;
    }

    public static int countString(String str, String k) {
        int count = 0;
        String[] words = str.split(" ");
        for (int i = 0; i < words.length; i++) {
            if (words[i].equalsIgnoreCase(k)) {
                count++;
            }
        }
        return count;
    }

    public static void main(String[] args) {
        int[] a = { 1, -2, 3, 4, -2, 1, -9 };
        // cau a
        System.out.println("Sum of negative elements: " + sumNegativeElements(a));

        // cau b
        String s = "nguyen thi uyen an";
        System.out.println("Uppercase first vowels: " + uppercaseFirstVowels(s));

        // cau c
        System.out.println("Min negative element index: " + findMinNegativeElement(a));

        // cau d
        String s1 = "Ho ten: Nguyen Thi Anh Dao";
        System.out.println("Get name: " + getName(s1));

        // cau e
        System.out.println("First mod 3 element index: " + findFirstMod3Element(a));

        // cau f
        String s2 = "Nguyen Phuong Hoang Anh Phuong Oanh";
        String k = "Phuong";
        System.out.println("Count string: " + countString(s2, k));
    }

}