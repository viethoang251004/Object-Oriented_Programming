public class Developer extends Employee {
    public Developer(String name) {
        super(name);
    }

    public String title() {
        return "Developer";
    }
}