import java.util.*;

public class TestRectangle { 
    public static void main(String[] args) {
        Rectangle rec = new Rectangle("Ruby", "Red", 6, 8);
        double rate = 3.0;
        System.out.println("Name: " + rec.getName());
        System.out.println("Color: " + rec.getColor());
        System.out.println("Width: " + rec.getWidth());
        System.out.println("Length: " + rec.getLength());
        System.out.println("Perimeter: " + rec.getPerimeter());
        System.out.println("Type: " + rec.getType());
        System.out.println("Is square: " + rec.isSquare());
        System.out.println("Diagonal line: " + rec.calDiagonalLine());
        System.out.println("To String: " + rec.toString());
        System.out.println("Resize:" +  new Rectangle);
    }
}