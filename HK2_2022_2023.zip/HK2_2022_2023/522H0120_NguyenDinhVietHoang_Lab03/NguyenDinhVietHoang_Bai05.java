import java.util.*;

public class NguyenDinhVietHoang_Bai05 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Read the input paragraph from the user
        System.out.println("Enter a paragraph: ");
        String paragraph = input.nextLine();

        // Read the input word from the user
        System.out.println("Enter a word to count its frequency: ");
        String word = input.nextLine().toLowerCase(); // convert to lowercase for case-insensitive comparison

        // Split the paragraph into an array of words
        String[] words = paragraph.split("\\s+");

        // Count the frequency of the word
        int frequency = 0;
        for (String w : words) {
            if (w.toLowerCase().equals(word)) { // convert to lowercase for case-insensitive comparison
                frequency++;
            }
        }

        // Print the frequency of the word
        System.out.println("Frequency of the word \"" + word + "\": " + frequency);

        // Create the 2-dimensional array to store the result
        String[][] result = new String[1][2];
        result[0][0] = word;
        result[0][1] = Integer.toString(frequency);

        // Print the result
        System.out.println("Result:");
        System.out.println("Word\tFrequency");
        System.out.println(result[0][0] + "\t" + result[0][1]);
    }
}