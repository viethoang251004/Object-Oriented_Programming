import java.util.*;

public class NguyenDinhVietHoang_Bai02 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Reading input matrices
        System.out.println("Enter the size of the matrices:");
        int m = input.nextInt();
        int n = input.nextInt();

        int[][] matrix1 = new int[m][n];
        int[][] matrix2 = new int[m][n];

        System.out.println("Enter the elements of the first matrix:");
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                matrix1[i][j] = input.nextInt();
            }
        }

        System.out.println("Enter the elements of the second matrix:");
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                matrix2[i][j] = input.nextInt();
            }
        }

        // Adding two matrices
        int[][] sum = addMatrices(matrix1, matrix2);
        System.out.println("The sum of the two matrices is:");
        printMatrix(sum);

        // Multiplying a matrix with a number
        System.out.println("Enter a number to multiply with the first matrix:");
        int num = input.nextInt();
        int[][] product = multiplyMatrixWithNumber(matrix1, num);
        System.out.println("The product of the first matrix and " + num + " is:");
        printMatrix(product);
    }

    public static int[][] addMatrices(int[][] matrix1, int[][] matrix2) {
        int m = matrix1.length;
        int n = matrix1[0].length;
        int[][] sum = new int[m][n];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                sum[i][j] = matrix1[i][j] + matrix2[i][j];
            }
        }

        return sum;
    }

    public static int[][] multiplyMatrixWithNumber(int[][] matrix, int num) {
        int m = matrix.length;
        int n = matrix[0].length;
        int[][] product = new int[m][n];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                product[i][j] = matrix[i][j] * num;
            }
        }

        return product;
    }

    public static void printMatrix(int[][] matrix) {
        int m = matrix.length;
        int n = matrix[0].length;

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }
}