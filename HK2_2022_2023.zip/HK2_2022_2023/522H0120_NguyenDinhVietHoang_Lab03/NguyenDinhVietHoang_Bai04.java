import java.util.*;

public class NguyenDinhVietHoang_Bai04 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Read the input string from the user
        System.out.println("Enter a string: ");
        String str = input.nextLine();

        // Find the length of the string
        int length = str.length();
        System.out.println("Length of the string: " + length);

        // Count the number of words in the string
        String[] words = str.split("\\s+");
        int wordCount = words.length;
        System.out.println("Number of words in the string: " + wordCount);

        // Concatenate one string's contents to another
        System.out.println("Enter another string to concatenate with the first one: ");
        String str2 = input.nextLine();
        String concatenatedString = str.concat(str2);
        System.out.println("Concatenated string: " + concatenatedString);

        // Check if a string is a palindrome or not
        String reverseString = "";
        for (int i = length - 1; i >= 0; i--) {
            reverseString = reverseString + str.charAt(i);
        }
        if (str.equals(reverseString)) {
            System.out.println("The string is a palindrome.");
        } else {
            System.out.println("The string is not a palindrome.");
        }
    }
}