import java.util.*;

public class NguyenDinhVietHoang_Bai01 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] array = new int[5];
        System.out.println("Enter 5 elements into the array:");
        for (int i = 0; i < array.length; i++) {
            array[i] = scanner.nextInt();
        }
        System.out.print("Array elements: ");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();

        //cau a
        System.out.print("Enter an element to remove: ");
        int elementToRemove = scanner.nextInt();
        boolean removed = removeElement(array, elementToRemove);
        if (removed) {
            System.out.println("Element removed successfully");
            System.out.print("Array elements after removal: ");
            for (int i = 0; i < array.length; i++) {
                System.out.print(array[i] + " ");
            }
            System.out.println();
        } else {
            System.out.println("Element not found in array");
        }

        //cau b
        System.out.print("Enter an element to insert: ");
        int elementToInsert = scanner.nextInt();
        System.out.print("Enter the position to insert the element: ");
        int position = scanner.nextInt();
        insertElement(array, elementToInsert, position);
        System.out.print("Array elements after insertion: ");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();

        //cau c
        int[] duplicates = findDuplicates(array);
        if (duplicates.length > 0) {
            System.out.print("Duplicate elements: ");
            for (int i = 0; i < duplicates.length; i++) {
                System.out.print(duplicates[i] + " ");
            }
            System.out.println();
        } else {
            System.out.println("No duplicate elements found in array");
        }

        //cau d
        int[] uniqueArray = removeDuplicates(array);
        System.out.print("Array elements after removing duplicates: ");
        for (int i = 0; i < uniqueArray.length; i++) {
            System.out.print(uniqueArray[i] + " ");
        }
        System.out.println();
    }

    public static boolean removeElement(int[] array, int element) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == element) {
                for (int j = i; j < array.length - 1; j++) {
                    array[j] = array[j + 1];
                }
                array[array.length - 1] = 0;
                return true;
            }
        }
        return false;
    }

    public static void insertElement(int[] array, int element, int position) {
        for (int i = array.length - 1; i > position; i--) {
            array[i] = array[i - 1];
        }
        array[position] = element;
        array[array.length - 1] = array[array.length - 2];
    }
    
    public static int[] findDuplicates(int[] array) {
        int[] duplicates = new int[0];
        for (int i = 0; i < array.length; i++) {
            for (int j = i + 1; j < array.length; j++) {
                if (array[i] == array[j]) {
                    int[] temp = new int[duplicates.length + 1];
                    for (int k = 0; k < duplicates.length; k++) {
                        temp[k] = duplicates[k];
                    }
                    temp[temp.length - 1] = array[i];
                    duplicates = temp;
                    break;
                }
            }
        }
        return duplicates;
    }

    public static int[] removeDuplicates(int[] array) {
        int[] uniqueArray = new int[array.length];
        int count = 0;
        for (int i = 0; i < array.length; i++) {
            boolean isDuplicate = false;
            for (int j = 0; j < count; j++) {
                if (array[i] == uniqueArray[j]) {
                    isDuplicate = true;
                    break;
                }
            }
            if (!isDuplicate) {
                uniqueArray[count++] = array[i];
            }
        }
        int[] result = new int[count];
        for (int i = 0; i < count; i++) {
            result[i] = uniqueArray[i];
        }
        return result;
    }
}