import java.util.*;

public class NguyenDinhVietHoang_Bai03 {

    public static void main(String[] args) {

	Scanner sc = new Scanner(System.in);
	System.out.printf("Enter your name: ");
	String fullName = sc.nextLine();
        
        // Test getFirstAndLastName function
        String firstAndLast = getFirstAndLastName(fullName);
        System.out.println("First and last name: " + firstAndLast);
        
        // Test getMiddleName function
        String middleName = getMiddleName(fullName);
        System.out.println("Middle name: " + middleName);
        
        // Test capitalizeName function
        String capitalized = capitalizeName(fullName);
        System.out.println("Capitalized name: " + capitalized);
        
        // Test vowelConsonantSwap function
        String swapped = vowelConsonantSwap(fullName);
        System.out.println("Vowel-consonant swapped name: " + swapped);
    }
    
    public static String getFirstAndLastName(String fullName) {
        String[] parts = fullName.split(" ");
        if (parts.length < 2) {
            return fullName;
        }
        String firstName = parts[0];
        String lastName = parts[parts.length - 1];
        return firstName + " " + lastName;
    }
    
    public static String getMiddleName(String fullName) {
        String[] parts = fullName.split(" ");
        if (parts.length < 3) {
            return "";
        }
        StringBuilder middleName = new StringBuilder();
        for (int i = 1; i < parts.length - 1; i++) {
            if (i != 1) {
                middleName.append(" ");
            }
            middleName.append(parts[i]);
        }
        return middleName.toString();
    }
    
    public static String capitalizeName(String fullName) {
        String[] parts = fullName.split(" ");
        StringBuilder capitalized = new StringBuilder();
        for (String part : parts) {
            if (part.length() > 1) {
                capitalized.append(Character.toUpperCase(part.charAt(0)));
                capitalized.append(part.substring(1).toLowerCase());
            } else {
                capitalized.append(Character.toUpperCase(part.charAt(0)));
            }
            capitalized.append(" ");
        }
        return capitalized.toString().trim();
    }
    
    public static String vowelConsonantSwap(String fullName) {
        StringBuilder swapped = new StringBuilder();
        for (int i = 0; i < fullName.length(); i++) {
            char c = fullName.charAt(i);
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
                    c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
                swapped.append(Character.toUpperCase(c));
            } else if (Character.isLetter(c)) {
                swapped.append(Character.toLowerCase(c));
            } else {
                swapped.append(c);
            }
        }
        return swapped.toString();
    }
}
