import java.util.*;

public class NguyenDinhVietHoang_Bai06
{
    
    public static void main(String[] args)
    {
        int a,b,c;
        Scanner sc = new Scanner(System.in);
        System.out.printf("Nhap so a: ");
        a = sc.nextInt();
        System.out.printf("Nhap so b: ");
        b = sc.nextInt();
        System.out.printf("Nhap so c: ");
        c = sc.nextInt();
        min(a,b,c);
        System.out.printf("So nho nhat trong 3 so la %d", min(a,b,c));
    }

    public static int min(int a, int b, int c)
    {
        int m = a;
        if(m > b)
            m = b;
        if(m > c)
            m = c;
        return m;
    }

}