import java.util.*;

public class NguyenDinhVietHoang_Bai11
{

    public static int countdigits(int n)
    {
        int count = 1;
        while(n >= 10)
        {
            n /= 10;
            count++;
        }
        return count;
    }

    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        int n, count;
        System.out.print("Nhap so can dem ki tu: ");
        n = sc.nextInt();

        count = countdigits(n);
        System.out.println("Tong so ki tu cua " + n + " la: "+count);
    }

}