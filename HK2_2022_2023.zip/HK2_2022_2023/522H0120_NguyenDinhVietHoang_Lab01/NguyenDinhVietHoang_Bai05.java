import java.util.*;

public class NguyenDinhVietHoang_Bai05
{

    public static void main(String[] args)
    {
        int nam;
        System.out.printf("Nhap nam: ");
        Scanner sc = new Scanner(System.in);
        nam = sc.nextInt();
        boolean kq = isLeafYear(nam);
        if(kq)
	        System.out.printf("Nhuan");
        else
	        System.out.printf("Khong nhuan");
    }
    
    public static boolean isLeafYear(int nam)
    {
	    if((nam % 400 == 0) || (nam % 4 == 0 && nam % 100 != 0))
		    return true;
	    else
		    return false;
    }

}