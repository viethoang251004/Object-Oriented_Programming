import java.util.*;

public class NguyenDinhVietHoang_Bai14
{
    public static void main(String[] args){
        int n, sotien, tienthua;
        
        Scanner sc = new Scanner(System.in);

        System.out.println("----Menu----");
        System.out.println("1. Coca");
        System.out.println("2. Pepsi");
        System.out.println("3. Sprite");
        System.out.println("4. Snack");
        System.out.println("5. Shutdown Machine");
        System.out.println("Please enter your number: ");
        n = sc.nextInt();
        
        if((n > 5 || (n < 0)))
            System.out.println("Please enter the valid number.");

        switch (n)
        {
            case 1:
                System.out.print("The price of Coca is 5$, please enter the amout of money: ");
                sotien = sc.nextInt();

                if(sotien < 5)
                    System.out.println("Not enough money to buy this item. Please seclect again.");
                else
                {
                    tienthua = sotien - 5;
                    System.out.println("Your change is: "+ tienthua +"$");
                }
                break;
            
            case 2:
                System.out.print("The price of Pepsi is 5$, please enter the amout of money: ");
                sotien = sc.nextInt();

                if(sotien < 5)
                    System.out.println("Not enough money to buy this item. Please seclect again.");
                else
                {
                    tienthua = sotien - 5;
                    System.out.println("Your change is: "+ tienthua +"$");
                }
                break;

            case 3:
                System.out.print("The price of Sprite is 3$, please enter the amout of money: ");
                sotien = sc.nextInt();

                if(sotien < 3){
                    System.out.println("Not enough money to buy this item. Please seclect again.");
                }
                else{
                    tienthua = sotien - 3;
                    System.out.println("Your change is: "+ tienthua +"$");
                }

                break;

            case 4:
                System.out.print("The price of Snack is 4$, please enter the amout of money: ");
                sotien = sc.nextInt();

                if(sotien<4){
                    System.out.println("Not enough money to buy this item. Please seclect again.");
                }
                else{
                    tienthua = sotien - 4;
                    System.out.println("Your change is: "+ tienthua +"$");
                }
                break;

            case 5:
                System.out.println("Machine is shutting down.");
                break;
        }

    }
}