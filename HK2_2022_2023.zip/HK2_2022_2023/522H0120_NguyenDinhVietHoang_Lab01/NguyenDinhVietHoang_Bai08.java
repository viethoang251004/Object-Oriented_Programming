import java.util.*;

public class NguyenDinhVietHoang_Bai08
{
    public static int cauA(int n){
        int i, a = 0;
        for(i=1; i<=n; i++){
            a +=i;
        }
        return a;
    }

    public static int cauB(int n){
        int i, b = 1;
        for(i=1; i<=n; i++){
            b *=i;
        }
        return b;
    }

    public static int cauC(int n){
        int i, c = 0;
        for(i=0; i<=n; i++){
            c += Math.pow(2,i);
        }
        return c;
    }

    public static double cauD(int n){
        int i;
        double d = 0;
        for(i=1; i<=n; i++){
            d += 1/(2.0*i);
        }
        return d;
    }

    public static int cauE(int n){
        int i, e = 0;
        for(i=1; i<=n; i++){
            e += Math.pow(i, 2);
        }
        return e;
    }
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        int i, n, b, a, c, e;
        double d;
        System.out.print("Nhap gia tri cua n: ");
        n= sc.nextInt();
        
        a = cauA(n);
        b = cauB(n);
        c = cauC(n);
        d = cauD(n);
        e = cauE(n);

        System.out.println("Cau a: "+ a);
        System.out.println("Cau b: "+ b);
        System.out.println("Cau c: "+ c);
        System.out.println("Cau d: "+ d);
        System.out.println("Cau e: "+ e);
    }
}