import java.util.*;

public class NguyenDinhVietHoang_Bai01
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.printf("Enter your name: ");
		String name = sc.nextLine();
		System.out.printf("Enter your date of birth: ");
		String dob = sc.nextLine();
		System.out.printf("Enter your student ID: ");
		String studentID = sc.nextLine();
		System.out.printf("Name: %s\n", name);
		System.out.printf("Date of birth: %s\n", dob);
		System.out.printf("StudentID: %s", studentID);
	}

}