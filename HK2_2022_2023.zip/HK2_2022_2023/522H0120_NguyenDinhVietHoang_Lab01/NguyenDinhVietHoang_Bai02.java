import java.util.*;

public class NguyenDinhVietHoang_Bai02
{

	public static void main(String[] args)
	{
		Scanner areaoftriangle = new Scanner(System.in);
		System.out.printf("Enter base: ");
		double base = areaoftriangle.nextDouble();
		System.out.printf("Enter height: ");
		double height = areaoftriangle.nextDouble();
		double area = 1.0/2.0 * base * height;
		System.out.printf("Area: %f", area);
	}

}