import java.util.*;

public class NguyenDinhVietHoang_Bai04
{

	public static void main(String[] args)
	{
		double celsius, fahrenheit;
		Scanner sc = new Scanner(System.in);

		System.out.printf("Nhap so Celsius: ");
		celsius = sc.nextDouble();
		System.out.printf("%f do C sang %f do F\n", celsius, csangf(celsius));
		
		System.out.printf("Nhap so Fahrenheit: ");
		fahrenheit = sc.nextDouble();
		System.out.printf("%f do F sang %f do C\n", fahrenheit, fsangc(fahrenheit));
	}

	public static double csangf(double celsius)
	{
		double f;
		f = 9.0 / 5.0 * celsius + 32;
		return f;
	}
	public static double fsangc(double fahrenheit)
	{
		double c;
		c = 5.0 / 9.0 * (fahrenheit - 32);
		return c;
	}

}