import java.util.*;

public class NguyenDinhVietHoang_Bai12
{

    public static int reverse(int n){
        int temp, dao = 0;

        while(n!=0){
            temp = n % 10;
            dao = dao * 10 + temp;
            n /= 10;
        }

        return dao;
    }

    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        int n, dao;
        System.out.print("Nhap so muon dao nguoc: ");
        n = sc.nextInt();

        dao = reverse(n);
        System.out.println("So " + n +"sau khi dao nguoc la: " + dao);
    }

}