import java.util.*;

public class NguyenDinhVietHoang_Bai13
{

    public static int palindrome(int n)
    {
        int temp, dao = 0;

        while(n != 0)
        {
            temp = n % 10;
            dao = dao * 10 + temp;
            n /= 10;
        }
        return dao;
    }

    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        int n, dao;
        System.out.print("Nhap so: ");
        n = sc.nextInt();
        
        dao = palindrome(n);
        if(dao == n)
            System.out.println(n + " la so palindrome");
        else
            System.out.println(n + " khong la so palindrome");
    }

}