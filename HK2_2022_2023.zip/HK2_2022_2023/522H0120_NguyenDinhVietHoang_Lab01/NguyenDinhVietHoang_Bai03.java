import java.util.*;

public class NguyenDinhVietHoang_Bai03
{

	public static void main(String[] args)
	{
		int n, y;
		System.out.printf("Nhap so n: ");
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		System.out.printf("Nhap so y: ");
		y = sc.nextInt();
		Chialaydu(n, y);
		System.out.printf("Phan du cua %d chia cho %d la %d", n, y, Chialaydu(n, y));
	}

	public static int Chialaydu(int n, int y)
	{
		int x;
		x = n % y;
		return x;
	}

}