import java.util.*;

public class NguyenDinhVietHoang_Bai09
{

    public static int tinh(int n)
    {
        while((n > 0) && (n != 1))
        {
            if(n % 2 == 0)
                n /= 2;
            else
                n = 3 * n + 1;
        }
        return n;
    }
    
    public static void main(String[] args)
    {
        Scanner sc =new Scanner(System.in);

        System.out.print("Nhap gia tri n: ");
        int n = sc.nextInt();

        tinh(n);
        n = tinh(n);
        System.out.println(n);
    }

}