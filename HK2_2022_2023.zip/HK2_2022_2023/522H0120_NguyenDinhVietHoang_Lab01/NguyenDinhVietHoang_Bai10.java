import java.util.*;

public class NguyenDinhVietHoang_Bai10
{

    public static int sumsdsc(int n)
    {
        int socuoi, sodau, sum;
        socuoi = n % 10;
        while (n >= 10)
            n = n / 10;
        sodau = n;
        sum = sodau + socuoi;
        return sum;
    }

    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        int n, sum;

        System.out.print("Nhap so: ");
        n = sc.nextInt();

        sum = sumsdsc(n);
        System.out.println("Tong so dau va so cuoi: " + sum);
    }

}