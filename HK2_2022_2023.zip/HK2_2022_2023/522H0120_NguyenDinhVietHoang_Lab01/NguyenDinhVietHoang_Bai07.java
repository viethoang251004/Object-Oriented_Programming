import java.util.*;

public class NguyenDinhVietHoang_Bai07
{
    
    public static void main(String[] args)
    {
	    Scanner sc = new Scanner(System.in);
	    System.out.printf("Nhap vao mot ky tu: ");
	    String s = sc.nextLine();
	    char c = s.charAt(0);
	
	    boolean kq=isAlpha(c);
	    if(kq)
		    System.out.printf("Do la ki tu");
	    else
		    System.out.printf("Do khong phai la ky tu");
    }
	
    public static boolean isAlpha(char c)
    {
		if((c >= 'a' && c <= 'z') || ( c >='A' && c<='Z'))
			return true;
		else
			return false;
    }

}
