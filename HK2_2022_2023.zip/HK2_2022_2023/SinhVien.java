import java.util.*;

public class SinhVien {
    private String maHocVien;
    private String hoTen;
    private String ngaySinh;
    private int namVaoHoc;
    private double diemDauVao;
    private Map<String, List<MonHoc>> danhSachMonHoc; // Danh sách môn học theo học kỳ
    private List<KetQuaHocTap> danhSachKetQuaHocTap; // Danh sách kết quả học tập

    public SinhVien(String maHocVien, String hoTen, String ngaySinh, int namVaoHoc, double diemDauVao) {
        this.maHocVien = maHocVien;
        this.hoTen = hoTen;
        this.ngaySinh = ngaySinh;
        this.namVaoHoc = namVaoHoc;
        this.diemDauVao = diemDauVao;
        this.danhSachMonHoc = new HashMap<>();
        this.danhSachKetQuaHocTap = new ArrayList<>();
    }

    public SinhVien(SinhVien sinhVien) {
        this.maHocVien = sinhVien.maHocVien;
        this.hoTen = sinhVien.hoTen;
        this.ngaySinh = sinhVien.ngaySinh;
        this.namVaoHoc = sinhVien.namVaoHoc;
        this.diemDauVao = sinhVien.diemDauVao;
        this.danhSachMonHoc = new HashMap<>(sinhVien.danhSachMonHoc);
        this.danhSachKetQuaHocTap = new ArrayList<>(sinhVien.danhSachKetQuaHocTap);
    }

    public String getMaHocVien() {
        return maHocVien;
    }

    public String getHoTen() {
        return hoTen;
    }

    public int getNamVaoHoc() {
        return namVaoHoc;
    }

    public double getDiemDauVao() {
        return diemDauVao;
    }

    public Map<String, List<MonHoc>> getDanhSachMonHoc() {
        return danhSachMonHoc;
    }

    public List<KetQuaHocTap> getDanhSachKetQuaHocTap() {
        return danhSachKetQuaHocTap;
    }

    public void themMonHoc(String hocKy, MonHoc monHoc) {
        if (danhSachMonHoc.containsKey(hocKy)) {
            danhSachMonHoc.get(hocKy).add(monHoc);
        } else {
            List<MonHoc> danhSachMonHocKy = new ArrayList<>();
            danhSachMonHocKy.add(monHoc);
            danhSachMonHoc.put(hocKy, danhSachMonHocKy);
        }
    }

    public void themKetQuaHocTap(KetQuaHocTap ketQuaHocTap) {
        int index = danhSachKetQuaHocTap.indexOf(ketQuaHocTap);
        if (index != -1) {
            danhSachKetQuaHocTap.set(index, ketQuaHocTap);
        } else {
            danhSachKetQuaHocTap.add(ketQuaHocTap);
        }
    }

    public String xacDinhLoaiHocVien() {
        if (this instanceof SinhVienChinhQuy) {
            return "Sinh viên chính quy";
        } else if (this instanceof SinhVienTaiChuc) {
            return "Sinh viên tại chức";
        } else if (this instanceof HocVienCaoHoc) {
            return "Học viên cao học";
        } else {
            return "Loại học viên không xác định";
        }
    }

    public double tinhDiemTrungBinhHocKy(String hocKy) {
        if (danhSachMonHoc.containsKey(hocKy)) {
            List<MonHoc> danhSachMonHocKy = danhSachMonHoc.get(hocKy);
            double tongDiem = 0;
            int soMonHoc = danhSachMonHocKy.size();

            for (MonHoc monHoc : danhSachMonHocKy) {
                tongDiem += monHoc.getDiemTrungBinh();
            }

            return tongDiem / soMonHoc;
        }
        return 0;
    }

    public double tinhDiemTrungBinhToanKhoa() {
        double tongDiem = 0;
        int soMonHoc = 0;

        for (List<MonHoc> danhSachMonHocKy : danhSachMonHoc.values()) {
            for (MonHoc monHoc : danhSachMonHocKy) {
                tongDiem += monHoc.getDiemTrungBinh();
                soMonHoc++;
            }
        }

        if (soMonHoc > 0) {
            return tongDiem / soMonHoc;
        }
        return 0;
    }

    public double tinhDiemTrungBinhTichLuy() {
        double tongDiem = 0;
        int soMonHoc = 0;

        for (List<MonHoc> danhSachMonHocKy : danhSachMonHoc.values()) {
            for (MonHoc monHoc : danhSachMonHocKy) {
                tongDiem += monHoc.getDiemTrungBinh();
                soMonHoc++;
            }
        }

        for (KetQuaHocTap ketQuaHocTap : danhSachKetQuaHocTap) {
            tongDiem += ketQuaHocTap.getDiemTrungBinh();
            soMonHoc++;
        }

        if (soMonHoc > 0) {
            return tongDiem / soMonHoc;
        }
        return 0;
    }
}
