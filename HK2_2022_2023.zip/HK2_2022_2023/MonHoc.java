public class MonHoc {
    private String maMon;
    private String tenMon;
    private double diemTrungBinh;

    public MonHoc(String maMon, String tenMon, double diemTrungBinh) {
        this.maMon = maMon;
        this.tenMon = tenMon;
        this.diemTrungBinh = diemTrungBinh;
    }

    public String getMaMon() {
        return maMon;
    }

    public String getTenMon() {
        return tenMon;
    }

    public double getDiemTrungBinh() {
        return diemTrungBinh;
    }
}
