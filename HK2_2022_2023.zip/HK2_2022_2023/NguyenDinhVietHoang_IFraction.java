public abstract interface NguyenDinhVietHoang_IFraction {
	public int getNumer();// returns numerator part

	public int getDenom(); // returns denominator part

	public void setNumer(int numer); // sets new numerator

	public void setDenom(int denom); // sets new denominator

	public NguyenDinhVietHoang_IFraction add(NguyenDinhVietHoang_IFraction f); // returns this + f

	public NguyenDinhVietHoang_IFraction minus(NguyenDinhVietHoang_IFraction f); // returns this - f

	public NguyenDinhVietHoang_IFraction times(NguyenDinhVietHoang_IFraction f); // returns this * f

	public NguyenDinhVietHoang_IFraction simplify(); // returns this simplified
}