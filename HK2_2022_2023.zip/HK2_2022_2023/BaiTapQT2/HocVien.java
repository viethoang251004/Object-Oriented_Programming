import java.util.*;

public class HocVien {
    private String maHV;
    private String HoTen;
    private String ngaythangnamSinh;
    private int namVaoHoc;
    private double diemDauVao;
    private List<String> danhsachMH;
    private List<String> danhsachKQHT;

    public HocVien() {
        this.maHV = "522H0120";
        this.HoTen = "Nguyen Dinh Viet Hoang";
        this.ngaythangnamSinh = "25/10/2004";
        this.namVaoHoc = 2022;
        this.diemDauVao = 32.48;
        this.danhsachMH = new ArrayList<>();
        this.danhsachKQHT = new ArrayList<>() ;
    }

    public HocVien(String maHV, String HoTen, String ngaythangnamSinh, int namVaoHoc, double diemDauVao,
            List<String> danhsachMH, List<String> danhsachKQHT) {
        this.maHV = maHV;
        this.HoTen = HoTen;
        this.ngaythangnamSinh = ngaythangnamSinh;
        this.namVaoHoc = namVaoHoc;
        this.diemDauVao = diemDauVao;
        this.danhsachMH = danhsachMH;
        this.danhsachKQHT = danhsachKQHT;
    }

    public HocVien(HocVien other) {
        this.maHV = other.maHV;
        this.HoTen = other.HoTen;
        this.ngaythangnamSinh = other.ngaythangnamSinh;
        this.namVaoHoc = other.namVaoHoc;
        this.diemDauVao = other.diemDauVao;
        this.danhsachMH = other.danhsachMH;
        this.danhsachKQHT = other.danhsachKQHT;
    }

    public String getmaHV() {
        return maHV;
    }

    public void setmaHV(String maHV) {
        this.maHV = maHV;
    }

    public String getHoTen() {
        return HoTen;
    }

    public void setHoTen(String HoTen) {
        this.HoTen = HoTen;
    }

    public String getngaythangnamSinh() {
        return ngaythangnamSinh;
    }

    public void setngaythangnamSinh(String ngaythangnamSinh) {
        this.ngaythangnamSinh = ngaythangnamSinh;
    }

    public int getnamVaoHoc() {
        return namVaoHoc;
    }

    public void setnamVaoHoc(int namVaoHoc) {
        this.namVaoHoc = namVaoHoc;
    }

    public double getdiemDauVao() {
        return diemDauVao;
    }

    public void setdiemDauVao(int diemDauVao) {
        this.diemDauVao = diemDauVao;
    }

    public List<String> getDanhsachMH() {
        return danhsachMH;
    }

    public void setDanhsachMH(ArrayList<String> danhsachMH) {
        this.danhsachMH = danhsachMH;
    }

    public List<String> getDanhsachKQHT() {
        return danhsachKQHT;
    }

    public void setDanhsachKQHT(ArrayList<String> danhsachKQHT) {
        this.danhsachKQHT = danhsachKQHT;
    }
}