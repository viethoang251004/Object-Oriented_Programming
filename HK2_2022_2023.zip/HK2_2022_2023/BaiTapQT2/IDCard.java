import java.time.LocalDate;

public class IDCard {
    private int soDinhDanh;
    private String hoTen;
    private String gioiTinh;
    private LocalDate ngayThangNamSinh;
    private String diaChi;
    private int soDienThoai;

    public IDCard(int soDinhDanh, String hoTen, String gioiTinh, LocalDate ngayThangNamSinh, String diaChi,
            int soDienThoai) {
        this.soDinhDanh = soDinhDanh;
        this.hoTen = hoTen;
        this.gioiTinh = gioiTinh;
        this.ngayThangNamSinh = ngayThangNamSinh;
        this.diaChi = diaChi;
        this.soDienThoai = soDienThoai;
    }

    public int getSoDinhDanh() {
        return soDinhDanh;
    }

    public void setSoDinhDanh(int soDinhDanh) {
        this.soDinhDanh = soDinhDanh;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public LocalDate getNgayThangNamSinh() {
        return ngayThangNamSinh;
    }

    public void setNgayThangNamSinh(LocalDate ngayThangNamSinh) {
        this.ngayThangNamSinh = ngayThangNamSinh;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public int getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(int soDienThoai) {
        this.soDienThoai = soDienThoai;
    }

    public String toString() {
        return "So dinh danh: " + soDinhDanh +
                "Ho ten: \n" + hoTen +
                "Gioi tinh: \n" + gioiTinh +
                "Ngay thang nam sinh: \n" + ngayThangNamSinh +
                "Dia chi: \n" + diaChi +
                "So dien thoai: \n" + soDienThoai;
    }
}
