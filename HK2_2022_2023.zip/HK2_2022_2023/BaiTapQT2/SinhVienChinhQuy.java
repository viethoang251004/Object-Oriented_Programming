import java.util.*;

public class SinhVienChinhQuy extends HocVien {
    public SinhVienChinhQuy(String maHV, String HoTen, String ngaythangnamSinh, int namVaoHoc, double diemDauVao, List<String> danhsachMH, List<String> danhsachKQHT) {
        super(maHV, HoTen, ngaythangnamSinh, namVaoHoc, diemDauVao, danhsachMH, danhsachKQHT);
    }
}
