import java.time.LocalDate;

public class ConvenientCard implements Payment {
    private String type;
    private IDCard theDinhDanh;
    private double soDuTaiKhoan;

    public ConvenientCard(IDCard theDinhDanh) {
        this.theDinhDanh = theDinhDanh;
        this.type = "Student";
        this.soDuTaiKhoan = 100;
    }

    public ConvenientCard(IDCard theDinhDanh) throws CannotCreateCard {
        LocalDate ngayThangNamSinh = theDinhDanh.getNgayThangNamSinh();
        if (ngayThangNamSinh.getYear() > LocalDate.now().getYear() - 12) {
            throw new CannotCreateCard("Not enough age");
        } else if (ngayThangNamSinh.getYear() > LocalDate.now().getYear() - 18) {
            this.type = "Student";
        } else {
            this.type = "Adult";
        }
        this.theDinhDanh = theDinhDanh;
        this.soDuTaiKhoan = 100;
    }

    public boolean pay(double amount) {
        double soTienCanThanhToan;
        if (type.equals("Student")) {
            soTienCanThanhToan = amount;
        } else if (type.equals("Adult")) {
            soTienCanThanhToan = amount + (0.01 * amount); // Them phi 1% vao so tien can thanh toan neu la nguoi lon
        } else {
            return false; // Loai the khong ton tai
        }

        if (soTienCanThanhToan <= soDuTaiKhoan) {
            soDuTaiKhoan = soDuTaiKhoan - soTienCanThanhToan;
            return true; // Thanh toan thanh cong va tra ve true
        } else {
            return false; // Khong du so du nen tra ve false
        }
    }

    public double checkBalance() {
        return soDuTaiKhoan;
    }

    public double soTienCanNap(double amount) {
        return soDuTaiKhoan += amount;
    }

    public String toString() {
        return theDinhDanh.toString() + "Type: " + type + "So du tai khoan: " + soDuTaiKhoan;
    }
}
