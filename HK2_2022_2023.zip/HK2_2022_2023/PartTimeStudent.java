import java.util.*;

// Lớp sinh viên tại chức
public class PartTimeStudent extends Student {
    private String trainingLocation;

    public PartTimeStudent(String studentId, String fullName, String dateOfBirth, int enrollmentYear,
            double entranceScore, String trainingLocation) {
        super(studentId, fullName, dateOfBirth, enrollmentYear, entranceScore);
        this.trainingLocation = trainingLocation;
    }

    public String getTrainingLocation() {
        return trainingLocation;
    }
}
