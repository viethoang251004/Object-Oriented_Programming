// ArrayList<BankAccount> result = new ArrayList<>();
// HashMap<Integer, Double> paymentAmounts = new HashMap<>();

// try {
//     File file = new File(path);
//     BufferedReader reader = new BufferedReader(new FileReader(file));
//     String line;

//     while ((line = reader.readLine()) != null) {
//         String[] parts = line.split(",");
//         int accountId = Integer.parseInt(parts[4]);
//         double paymentAmount = Double.parseDouble(parts[1]);

//         if (!paymentAmounts.containsKey(accountId)) {
//             paymentAmounts.put(accountId, paymentAmount);
//         } else {
//             double currentAmount = paymentAmounts.get(accountId);
//             paymentAmounts.put(accountId, currentAmount + paymentAmount);
//         }
//     }

//     reader.close();
// } catch (IOException e) {
//     e.printStackTrace();
// }

// double maxAmount = 0;

// for (double amount : paymentAmounts.values()) {
//     if (amount > maxAmount) {
//         maxAmount = amount;
//     }
// }

// for (Payment payment : paymentObjects) {
//     if (payment instanceof BankAccount) {
//         BankAccount bankAccount = (BankAccount) payment;
//         if (paymentAmounts.containsKey(bankAccount.getAccountNumber()) && paymentAmounts.get(bankAccount.getAccountNumber()) == maxAmount) {
//             result.add(bankAccount);
//         }
//     }
// }

// return result;