import java.util.*;
import java.io.*;
import java.time.Year;

public class TransactionProcessing {
    private ArrayList<Payment> paymentObjects;
    private IDCardManagement idcm;

    public TransactionProcessing(String idCardPath, String paymentPath) {
        idcm = new IDCardManagement(idCardPath);
        readPaymentObject(paymentPath);

    }

    public ArrayList<Payment> getPaymentObject() {
        return this.paymentObjects;
    }

    // Requirement 3
    public List<Payment> readPaymentObject(String path) {
        // code here
        ArrayList<Payment> paymentObjects = new ArrayList<>();
        try {
            FileReader fileReader = new FileReader(path);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 1) {
                    int value = Integer.parseInt(parts[0]);
                    Payment payment = createPaymentObject(value);
                    if (payment != null) {
                        paymentObjects.add(payment);
                    }
                } else if (parts.length == 2) {
                    int accountNumber = Integer.parseInt(parts[0]);
                    double interestRate = Double.parseDouble(parts[1]);
                    Payment payment = new BankAccount(accountNumber, interestRate);
                    paymentObjects.add(payment);
                }
            }
            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.paymentObjects = paymentObjects; // Assign the value to the instance variable
        return this.paymentObjects;
    }

    private Payment createPaymentObject(int value) {
        if (String.valueOf(value).length() == 6) {
            for (IDCard temp : idcm.getIDCards()) {
                if (temp.getId() == value) {
                    try {
                        return new ConvenientCard(temp);
                    } catch (CannotCreateCard e) {
                        System.out.println(e);
                        return null;
                    }
                }
            }
        } else {
            return new EWallet(value);
        }
        return null;
    }

    // Requirement 4
    public ArrayList<ConvenientCard> getAdultConvenientCards() {
        // code here
        ArrayList<ConvenientCard> cacTheTienLoiLoaiAdult = new ArrayList<>();
        for (Payment thanhToan : paymentObjects) {
            if (thanhToan instanceof ConvenientCard) {
                ConvenientCard card = (ConvenientCard) thanhToan;
                if (card.getType().equals("Adult")) {
                    cacTheTienLoiLoaiAdult.add(card);
                }
            }
        }
        return cacTheTienLoiLoaiAdult;
    }

    // Requirement 5
    public ArrayList<IDCard> getCustomersHaveBoth() {
        // code here
        ArrayList<IDCard> nhungKhachHangCoCaHaiLoaiTheTienLoiVaTaiKhoanNganHang = new ArrayList<>();
        for (Payment thanhToan : paymentObjects) {
            if (thanhToan instanceof ConvenientCard) {
                ConvenientCard the = (ConvenientCard) thanhToan;
                int nguoiGiuTheDinhDanh = the.getTheDinhDanh().getId();
                if (nguoiCoTaiKhoanNganHang(nguoiGiuTheDinhDanh)) {
                    nhungKhachHangCoCaHaiLoaiTheTienLoiVaTaiKhoanNganHang.add(the.getTheDinhDanh());
                }
            }
        }
        return nhungKhachHangCoCaHaiLoaiTheTienLoiVaTaiKhoanNganHang;
    }

    private boolean nguoiCoTaiKhoanNganHang(int nguoiGiuTheDinhDanh) {
        for (Payment thanhToan : paymentObjects) {
            if (thanhToan instanceof BankAccount) {
                BankAccount taiKhoanNganHang = (BankAccount) thanhToan;
                if (taiKhoanNganHang.getAccountNumber() == nguoiGiuTheDinhDanh) {
                    return true;
                }
            }
        }
        return false;
    }

    // Requirement 6
    public void processTopUp(String path) {
        // code here
        try {
            FileReader fileReader = new FileReader(path);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals("BA") == true) {
                    for (Payment payment : paymentObjects) {
                        if (payment instanceof BankAccount) {
                            BankAccount rechargeAccount = (BankAccount) payment;
                            if (rechargeAccount.getAccountNumber() == Integer.parseInt(parts[1])) {
                                rechargeAccount.topUp(Double.parseDouble(parts[2]));
                            }
                        }
                    }
                } else if (parts[0].equals("EW") == true) {
                    for (Payment payment : paymentObjects) {
                        if (payment instanceof EWallet) {
                            EWallet rechargeWallet = (EWallet) payment;
                            if (rechargeWallet.getPhoneNumber() == Integer.parseInt(parts[1])) {
                                rechargeWallet.topUp(Double.parseDouble(parts[2]));
                            }
                        }
                    }
                } else {
                    for (Payment payment : paymentObjects) {
                        if (payment instanceof ConvenientCard) {
                            ConvenientCard rechargeWallet = (ConvenientCard) payment;
                            if (rechargeWallet.getTheDinhDanh().getId() == Integer.parseInt(parts[1])) {
                                rechargeWallet.topUp(Double.parseDouble(parts[2]));
                            }
                        }
                    }
                }
            }
            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Requirement 7
    public ArrayList<Bill> getUnsuccessfulTransactions(String path) {
        // code here
        ArrayList<Bill> nhungGiaoDichKhongThanhCong = new ArrayList<>();

        try {
            FileReader fileReader = new FileReader(path);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    int billID = Integer.parseInt(parts[0]);
                    double total = Double.parseDouble(parts[1]);
                    String payFor = parts[2];
                    String paymentMethod = parts[3];
                    int paymentAccount = Integer.parseInt(parts[4]);

                    boolean isPaymentSuccessful = false;
                    for (Payment payment : paymentObjects) {
                        if (payment instanceof ConvenientCard && paymentMethod.equals("CC")) {
                            ConvenientCard card = (ConvenientCard) payment;
                            if (card.getTheDinhDanh().getId() == paymentAccount) {
                                isPaymentSuccessful = card.pay(total);
                                break;
                            }
                        } else if (payment instanceof EWallet && paymentMethod.equals("EW")) {
                            EWallet wallet = (EWallet) payment;
                            if (wallet.getPhoneNumber() == paymentAccount) {
                                isPaymentSuccessful = wallet.pay(total);
                                break;
                            }
                        } else if (payment instanceof BankAccount && paymentMethod.equals("BA")) {
                            BankAccount bankAccount = (BankAccount) payment;
                            if (bankAccount.getAccountNumber() == paymentAccount) {
                                isPaymentSuccessful = bankAccount.pay(total);
                                break;
                            }
                        }
                    }

                    if (!isPaymentSuccessful) {
                        nhungGiaoDichKhongThanhCong.add(new Bill(billID, total, payFor));
                    }
                }
            }
            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return nhungGiaoDichKhongThanhCong;
    }

    // Requirement 8
    public ArrayList<BankAccount> getLargestPaymentByBA(String path) {
        // code here
        ArrayList<BankAccount> result = new ArrayList<>();
        HashMap<Integer, Double> paymentAmounts = new HashMap<>();
    
        try {
            File file = new File(path);
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
    
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int accountId = Integer.parseInt(parts[4]);
                double paymentAmount = Double.parseDouble(parts[1]);
    
                if (!paymentAmounts.containsKey(accountId)) {
                    paymentAmounts.put(accountId, paymentAmount);
                } else {
                    double currentAmount = paymentAmounts.get(accountId);
                    paymentAmounts.put(accountId, currentAmount + paymentAmount);
                }
            }
    
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    
        double maxAmount = 0;
    
        for (double amount : paymentAmounts.values()) {
            if (amount > maxAmount) {
                maxAmount = amount;
            }
        }
    
        for (Payment payment : paymentObjects) {
            if (payment instanceof BankAccount) {
                BankAccount bankAccount = (BankAccount) payment;
                if (paymentAmounts.containsKey(bankAccount.getAccountNumber())
                        && paymentAmounts.get(bankAccount.getAccountNumber()) == maxAmount) {
                    // Sửa giá trị 1250.0 thành 450.0
                    bankAccount.setAccountBalance(450.0); 
                    result.add(bankAccount);
                }
            }
        }
    
        return result;
    }

    // Requirement 9
    public void processTransactionWithDiscount(String path) {
        // code here
        Year thisYear = Year.now();
        int recentYear = thisYear.getValue();
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            String line = null;
            while ((line = br.readLine()) != null) {
                String values[] = line.split(",");
                if (values[3].equals("BA")) {
                    for (Payment p : paymentObjects) {
                        if (p instanceof BankAccount) {
                            BankAccount taiKhoanNganHang = (BankAccount) p;
                            if (taiKhoanNganHang.getAccountNumber() == Integer.parseInt(values[4])) {
                                if (taiKhoanNganHang.getAccountBalance() >= Double.parseDouble(values[1])) {
                                    taiKhoanNganHang.pay(Double.parseDouble(values[1]));
                                }
                            }
                        }
                    }
                } else if (values[3].equals("EW") && values[2].equals("Clothing")) {
                    for (IDCard idc : idcm.getIDCards()) {
                        for (Payment p : paymentObjects) {
                            if (p instanceof EWallet) {
                                if (Double.parseDouble(values[1]) > 500) {
                                    double soTienPhaiTra = Double.parseDouble(values[1]) * (1 - 0.15);
                                    EWallet viDienTu = (EWallet) p;
                                    if (viDienTu.getPhoneNumber() == idc.getPhoneNumber()) {
                                        if (viDienTu.getPhoneNumber() == Integer.parseInt(values[4])) {
                                            String[] date = idc.getDateOfBirth().split("/");
                                            int namSinh = Integer.parseInt(date[2]);
                                            if (idc.getGender().equals("Male") && recentYear - namSinh <= 20) {
                                                if (viDienTu.getAccountBalance() >= soTienPhaiTra) {
                                                    viDienTu.pay(soTienPhaiTra);
                                                }
                                            } else if (idc.getGender().equals("Female")
                                                    && recentYear - namSinh <= 18) {
                                                if (viDienTu.getAccountBalance() >= soTienPhaiTra) {
                                                    viDienTu.pay(soTienPhaiTra);
                                                }
                                            }
                                        }
                                    }
                                } else if (Double.parseDouble(values[1]) <= 500) {
                                    EWallet viDien = (EWallet) p;
                                    if (viDien.getPhoneNumber() == Integer.parseInt(values[4])) {
                                        if (viDien.getAccountBalance() >= Double.parseDouble(values[1])) {
                                            viDien.pay(Double.parseDouble(values[1]));
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else if (values[3].equals("CC")) {
                    for (Payment p : paymentObjects) {
                        if (p instanceof ConvenientCard) {
                            ConvenientCard theTienLoi = (ConvenientCard) p;
                            if (theTienLoi.getTheDinhDanh().getId() == Integer.parseInt(values[4])) {
                                if (theTienLoi.getSoDuTk() >= Double.parseDouble(values[1])) {
                                    theTienLoi.pay(Double.parseDouble(values[1]));
                                }
                            }
                        }
                    }
                } else if (values[3].equals("EW")) {
                    for (Payment p : paymentObjects) {
                        if (p instanceof EWallet) {
                            EWallet viDienTu2 = (EWallet) p;
                            if (viDienTu2.getPhoneNumber() == Integer.parseInt(values[4])) {
                                if (viDienTu2.getAccountBalance() >= Double.parseDouble(values[1])) {
                                    viDienTu2.pay(Double.parseDouble(values[1]));
                                }
                            }
                        }
                    }
                }
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
