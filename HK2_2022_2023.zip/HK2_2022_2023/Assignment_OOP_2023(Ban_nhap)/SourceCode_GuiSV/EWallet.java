public class EWallet implements Payment, Transfer {
	// code here
    private int phoneNumber;
    private double accountBalance;

    public EWallet(int phoneNumber) {
        this.phoneNumber = phoneNumber;
        this.accountBalance = 0;
    }

    public boolean pay(double amount) {
        if (amount <= this.accountBalance) {
            this.accountBalance = this.accountBalance - amount;
            return true;
        } else {
            return false;
        }
    }

    public double checkBalance() {
        return this.accountBalance;
    }

    public boolean transfer(double amount, Transfer to) {
        double transferAmount = amount + Transfer.transferFee * amount;
        if (transferAmount <= this.accountBalance) {
            this.accountBalance -= transferAmount;
            if (to instanceof EWallet) {
                ((EWallet) to).topUp(amount);
            } else if (to instanceof BankAccount) {
                ((BankAccount) to).topUp(amount);
            }
            return true;
        }
        return false;
    }

    public void topUp(double amount) {
        this.accountBalance = this.accountBalance + amount;
    }

    public String toString() {
        return this.phoneNumber + "," + this.accountBalance;
    }

    public int getPhoneNumber() {
        return this.phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public double getAccountBalance() {
        return this.accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }
}
