public class BankAccount implements Payment, Transfer {
    // code here
    private int accountNumber;
    private double interestRate;
    private double accountBalance;

    public BankAccount(int accountNumber, double interestRate) {
        this.accountNumber = accountNumber;
        this.interestRate = interestRate;
        this.accountBalance = 50;
    }

    public BankAccount(String accountNumber2, int interestRate2, double accountBalance) {
        this.accountNumber = Integer.parseInt(accountNumber2);
        this.interestRate = interestRate2;
        this.accountBalance = accountBalance;
    }

    public boolean pay(double amount) {
        if (amount + 50 <= this.accountBalance) {
            this.accountBalance -= amount;
            return true;
        }
        return false;
    }

    public double checkBalance() {
        return this.accountBalance;
    }

    public boolean transfer(double amount, Transfer to) {
        double transferAmount = amount + Transfer.transferFee * amount;
        if (transferAmount <= this.accountBalance - 50) {
            this.accountBalance -= transferAmount;
            if (to instanceof BankAccount) {
                ((BankAccount) to).topUp(amount);
            } else if (to instanceof EWallet) {
                ((EWallet) to).topUp(amount);
            }
            return true;
        }
        return false;
    }

    public void topUp(double amount) {
        this.accountBalance = this.accountBalance + amount;
    }

    public String toString() {
        return this.accountNumber + "," + this.interestRate + "," + this.accountBalance;
    }

    public int getAccountNumber() {
        return this.accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public double getInterestRate() {
        return this.interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public double getAccountBalance() {
        return this.accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    public void withdraw(double amount) {
        this.accountBalance = this.accountBalance - amount;
    }
}
