import java.time.Year;

public class ConvenientCard implements Payment {
	// code here
	private String type;
	private IDCard theDinhDanh;
	private double soDuTk;

	private int tinhTuoiHienTai(String ngayThangNamSinh) {
		int tuoiTac = 0;

		// Tách ngày, tháng, năm từ chuỗi ngayThangNamSinh
		String[] parts = ngayThangNamSinh.split("/");
		int namSinh = Integer.parseInt(parts[2]);
	
		// Lấy năm hiện tại
		int namHienTai = Year.now().getValue();
	
		// Tính tuổi bằng cách lấy năm hiện tại trừ đi năm sinh
		tuoiTac = namHienTai - namSinh;
	
		return tuoiTac;
	}

	public ConvenientCard(IDCard theDinhDanh) throws CannotCreateCard {
		super();
		this.theDinhDanh = theDinhDanh;
		this.soDuTk = 100;

		int tuoitac = tinhTuoiHienTai(theDinhDanh.getDateOfBirth());

		if (tuoitac < 12) {
			throw new CannotCreateCard("Not enough age");
		} else if (tuoitac <= 18) {
			this.type = "Student";
		} else {
			this.type = "Adult";
		}
	}

	public boolean pay(double amount) {
		double soTienCanThanhToan = amount;

		if (type.equals("Student")) {
			soTienCanThanhToan = amount;
		}

		if (type.equals("Adult")) {
			soTienCanThanhToan = soTienCanThanhToan + (0.01 * amount); //Them phi 1% vao so tien can thanh toan neu la nguoi lon
		}

		if (soTienCanThanhToan <= soDuTk) {
			soDuTk = soDuTk - soTienCanThanhToan;
			return true; //Thanh toan thanh cong va tra ve true
		} else {
			return false; //Khong du so du nen tra ve false
		}
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
			this.type = type;
		}

	public IDCard getTheDinhDanh() {
		return this.theDinhDanh;
	}

	public void setTheDinhDanh(IDCard theDinhDanh) {
        this.theDinhDanh = theDinhDanh;
    }

	public double getSoDuTk() {
		return this.soDuTk;
	}

	public void setSoDuTK(double soDuTk) {
		this.soDuTk = soDuTk;
	}

	public double checkBalance() {
		return this.soDuTk;
	}

	public void topUp(double amount) {
		this.soDuTk = this.soDuTk + amount;
	}

	public String toString() {
		return this.theDinhDanh + "," + type + "," + soDuTk;
	}
}
