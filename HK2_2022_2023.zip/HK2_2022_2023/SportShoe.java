import java.util.*;
import java.io.*;

class SportShoe extends Product {
    private String shoeType;
    private String suitableSurface;
    private int unitPrice;

    public SportShoe() {
    }

    public SportShoe(String productCode, String productName, String material, int size, String color,
            int productionYear, String shoeType, String suitableSurface, int unitPrice) {
        super(productCode, productName, material, size, color, productionYear);
        this.shoeType = shoeType;
        this.suitableSurface = suitableSurface;
        this.unitPrice = unitPrice;
    }

    public String getShoeType() {
        return shoeType;
    }

    public void setShoeType(String shoeType) {
        this.shoeType = shoeType;
    }

    public String getSuitableSurface() {
        return suitableSurface;
    }

    public void setSuitableSurface(String suitableSurface) {
        this.suitableSurface = suitableSurface;
    }

    public int getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(int unitPrice) {
        this.unitPrice = unitPrice;
    }

    @Override
    public int calculateCost() {
        return unitPrice;
    }
}
