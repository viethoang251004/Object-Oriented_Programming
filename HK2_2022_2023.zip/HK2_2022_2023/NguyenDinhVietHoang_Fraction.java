class NguyenDinhVietHoang_Fraction implements NguyenDinhVietHoang_IFraction {
    // Data members
    private int numer;
    private int denom;

    // Constructors
    public NguyenDinhVietHoang_Fraction() {
        this(1, 1);
    }

    public NguyenDinhVietHoang_Fraction(int numer, int denom) {
        setNumer(numer);
        setDenom(denom);
    }

    // Accessors
    public int getNumer() {
        return this.numer;
    }

    public int getDenom() {
        return this.denom;
    }

    // Mutators
    public void setNumer(int numer) {
        this.numer = numer;
    }

    public void setDenom(int denom) {
        if (denom == 0) {
            throw new IllegalArgumentException("Denominator cannot be zero");
        }
        this.denom = denom;
    }

    // Returns greatest common divisor of a and b
    // private method as this is not accessible to clients
    private static int gcd(int a, int b) {
        int rem;
        while (b > 0) {
            rem = a % b;
            a = b;
            b = rem;
        }
        return a;
    }

    public NguyenDinhVietHoang_IFraction simplify() {
        int gcd = gcd(numer, denom);
        int newNumer = numer / gcd;
        int newDenom = denom / gcd;
        return new NguyenDinhVietHoang_Fraction(newNumer, newDenom);
    }

    public NguyenDinhVietHoang_IFraction add(NguyenDinhVietHoang_IFraction f) {
        int newNumer = this.numer * f.getDenom() + f.getNumer() * this.denom;
        int newDenom = this.denom * f.getDenom();
        return new NguyenDinhVietHoang_Fraction(newNumer, newDenom).simplify();
    }

    public NguyenDinhVietHoang_IFraction minus(NguyenDinhVietHoang_IFraction f) {
        int newNumer = this.numer * f.getDenom() - f.getNumer() * this.denom;
        int newDenom = this.denom * f.getDenom();
        return new NguyenDinhVietHoang_Fraction(newNumer, newDenom).simplify();
    }

    public NguyenDinhVietHoang_IFraction times(NguyenDinhVietHoang_IFraction f) {
        int newNumer = this.numer * f.getNumer();
        int newDenom = this.denom * f.getDenom();
        return new NguyenDinhVietHoang_Fraction(newNumer, newDenom).simplify();
    }

    // Overriding methods toString() and equals()
    @Override
    public String toString() {
        return numer + "/" + denom;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof NguyenDinhVietHoang_Fraction) {
            NguyenDinhVietHoang_Fraction other = (NguyenDinhVietHoang_Fraction) obj;
            return this.numer == other.numer && this.denom == other.denom;
        }
        return false;
    }
}