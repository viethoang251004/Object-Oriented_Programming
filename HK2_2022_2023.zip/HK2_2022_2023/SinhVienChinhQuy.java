public class SinhVienChinhQuy extends SinhVien {
    public SinhVienChinhQuy(String maHocVien, String hoTen, String ngaySinh, int namVaoHoc, double diemDauVao) {
        super(maHocVien, hoTen, ngaySinh, namVaoHoc, diemDauVao);
    }
}
