if (nhungGiaTri[3].equals("CC")) {
    for (Payment p : paymentObjects) {
        if (p instanceof ConvenientCard) {
            ConvenientCard theTienLoi = (ConvenientCard) p;
            if (theTienLoi.getTheDinhDanh().getSoDinhDanh() == Integer.parseInt(nhungGiaTri[4])) {
                if (theTienLoi.getSoDuTk() >= Double.parseDouble(nhungGiaTri[1])) {
                    theTienLoi.pay(Double.parseDouble(nhungGiaTri[1]));
                }
            }
        }
    }
}