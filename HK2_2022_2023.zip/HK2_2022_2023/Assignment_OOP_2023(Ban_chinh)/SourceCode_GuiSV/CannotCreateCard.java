//Dont modify this file

public class CannotCreateCard extends Exception{
    public CannotCreateCard(String message) {
        super(message);
    }
}
