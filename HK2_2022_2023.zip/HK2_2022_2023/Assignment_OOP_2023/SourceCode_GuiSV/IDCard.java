public class IDCard {
      // code here
}
