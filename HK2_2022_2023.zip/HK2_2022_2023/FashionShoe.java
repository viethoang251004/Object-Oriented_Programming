import java.util.*;
import java.io.*;

class FashionShoe extends Product {
    private int heelHeight;
    private String toeType;
    private int unitPrice;

    public FashionShoe() {
    }

    public FashionShoe(String productCode, String productName, String material, int size, String color,
            int productionYear, int heelHeight, String toeType, int unitPrice) {
        super(productCode, productName, material, size, color, productionYear);
        this.heelHeight = heelHeight;
        this.toeType = toeType;
        this.unitPrice = unitPrice;
    }

    public int getHeelHeight() {
        return heelHeight;
    }

    public void setHeelHeight(int heelHeight) {
        this.heelHeight = heelHeight;
    }

    public String getToeType() {
        return toeType;
    }

    public void setToeType(String toeType) {
        this.toeType = toeType;
    }

    public int getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(int unitPrice) {
        this.unitPrice = unitPrice;
    }

    @Override
    public int calculateCost() {
        return unitPrice;
    }
}
